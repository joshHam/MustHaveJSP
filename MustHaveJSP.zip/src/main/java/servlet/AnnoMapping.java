package servlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
/**
 * Servlet implementation class AnnoMapping
 */
@WebServlet("/12Servlet/AnnoMapping.do")
public class AnnoMapping extends HttpServlet {
	private static final long serialVersionUID = 1L;
	@Override
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setAttribute("message", "@WebServlet으로 매핑");
//		request.getRequestDispatcher("/12Servlet/HelloServlet.jsp").forward(request, response);
				request.getRequestDispatcher("/12Servlet/AnnoMapping.jsp").forward(request, response);
//		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

}
